# Tabi-Tab

A simple list management web-app. 

### TO COMPILE:
>**Requirement: npm**.

To install necessary dependencies for compiling:
```
"npm run get-dependencies"
``` 

To build Tabi Tab:
``` 
"npm run compile"
``` 
Finally, run Tabi-Tab by open index.html in folder .\dist.

