import { Enum } from "../../Utils.js";

export const TextType = Enum.Create("HEADER", "SECTION", "PARAGRAPH", "PARAGRAPH_BOLD");
