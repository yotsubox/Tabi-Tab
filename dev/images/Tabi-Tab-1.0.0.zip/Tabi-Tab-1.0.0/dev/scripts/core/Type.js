import { Enum } from "./Utils/Enum.js";

export const Type = Enum.Create("TAB_LIST", "TAB_LIST_ITEM");
