export { saveWhenCtrlS } from "./Events/saveWhenCtrlS.js";
export { saveEveryTenSec } from "./Events/saveEveryTenSec.js";
export { showPage } from "./Events/showPage.js";
export { scrollToLastOpenedPosition } from "./Events/scrollToLastOpenedPosition.js";
