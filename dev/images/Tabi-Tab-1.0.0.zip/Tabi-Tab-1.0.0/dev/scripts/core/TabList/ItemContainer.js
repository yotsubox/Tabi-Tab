import { createElement } from "../Utils/createElement.js";

export class ItemContainer {
  static Create(tabList) {
    const itemContainer = createElement("div", "list__item-wrapper");

    return itemContainer;
  }
}
