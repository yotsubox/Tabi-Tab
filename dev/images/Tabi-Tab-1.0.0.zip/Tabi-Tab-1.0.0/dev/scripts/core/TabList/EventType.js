import { Enum } from "../Utils.js";

export const EventType = Enum.Create("REMOVED");
