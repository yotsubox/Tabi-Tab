import { createElement } from "../../../../Utils.js";

export function createOptionName() {
  return createElement("div", "list-menu__option-name");
}
