export function newDefaultSettings() {
  return {
    minimized: false,
    unorderedList: false,
  };
}
