import { createElement } from "../../../../Utils.js";

export function createOptionElement() {
  return createElement("div", "list-menu__option --pointer-cursor");
}
