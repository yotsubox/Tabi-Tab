import { Enum } from "../../Utils/Enum.js";

export const EventType = Enum.Create("CHANGED", "SAVED");
